# DevInfo Pro

DevCheck-style system monitor. Real CPU / GPU / RAM / frequencies / temps / FPS, read through Shizuku (shell access).
Battery, Device, Display and Sensors tabs are small and use normal Android APIs.

## Build

**Android Studio:** open this folder, wait for Gradle sync, then Build > Build APK(s).

**GitHub Actions (no PC setup):** push this folder to a GitHub repo. Actions > "Build APK" > Run workflow.
Download `DevInfoPro-debug-apk` from the run's Artifacts (it is a zip containing `app-debug.apk`).

## Use

1. Install Shizuku and start it (Wireless debugging or root).
2. Open DevInfo Pro and tap **Shizuku permission**, then allow.
3. Tabs: Live, CPU, GPU, RAM, Battery, Device, Display, Sensors.
4. **FPS overlay**: allow "display over other apps", then open any game or app. The box shows FPS of the app in the foreground, plus CPU / GPU / RAM. Tap the box to close it.

## Notes

- Without Shizuku the app still runs, but GPU renderer, FPS and some sysfs values will be missing.
- GPU frequency/load and DDR frequency depend on what the kernel exposes (Adreno `kgsl` and Mali/Exynos `devfreq` are handled). Missing values are shown as "not readable" rather than invented.
- FPS comes from `dumpsys SurfaceFlinger --latency`; some Android versions or ROMs restrict it, in which case it falls back to `dumpsys gfxinfo` (works for normal apps, not for most games).
