package com.devinfo.pro

/** FPS of the app currently in the foreground, read from SurfaceFlinger (needs Shizuku). */
object Fps {

    class R(val pkg: String, val fps: Double, val src: String)

    private var layerPkg = ""
    private var layer = ""
    private var gPkg = ""
    private var gFrames = -1L
    private var gT = 0L
    private val focusRe = Regex("(\\S+)/(\\S+)\\}")

    @Synchronized
    fun measure(): R? {
        val focus = Sh.run("dumpsys window | grep -m1 mCurrentFocus")
        val pkg = focusRe.find(focus)?.groupValues?.get(1) ?: return null

        if (pkg != layerPkg || layer.isEmpty()) {
            layer = findLayer(pkg)
            layerPkg = pkg
        }
        if (layer.isNotEmpty()) {
            val f = latencyFps(layer)
            if (f != null) return R(pkg, f, "SurfaceFlinger")
            layer = "" // re-detect next time
        }
        return gfxinfoFps(pkg)
    }

    private fun findLayer(pkg: String): String {
        val c = Sh.run("dumpsys SurfaceFlinger --list").lines().map { it.trim() }.filter {
            it.contains(pkg) && !it.contains("Background") && !it.contains("Splash") && !it.contains("Bounds")
        }
        return c.firstOrNull { it.startsWith("SurfaceView") }
            ?: c.firstOrNull { it.contains("BLAST") }
            ?: c.firstOrNull()
            ?: ""
    }

    private fun latencyFps(name: String): Double? {
        val lines = Sh.run("dumpsys SurfaceFlinger --latency '$name'")
            .lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size < 3) return null
        val ts = lines.drop(1)
            .mapNotNull { l -> l.split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }
            .filter { it > 0 && it < Long.MAX_VALUE }
        if (ts.isEmpty()) return null
        val mx = ts.max()
        // newest frame is old -> screen is static
        if (System.nanoTime() - mx > 1_500_000_000L) return 0.0
        val recent = ts.filter { mx - it <= 1_000_000_000L }
        if (recent.size < 2) return 0.0
        val span = (mx - recent.min()) / 1e9
        return if (span > 0) (recent.size - 1) / span else null
    }

    private fun gfxinfoFps(pkg: String): R? {
        val out = Sh.run("dumpsys gfxinfo $pkg | grep -m1 'Total frames rendered'")
        val n = Regex("(\\d+)").find(out)?.value?.toLongOrNull() ?: return null
        val now = System.nanoTime()
        val r = if (pkg == gPkg && gFrames >= 0 && now > gT) {
            R(pkg, (n - gFrames) * 1e9 / (now - gT), "gfxinfo")
        } else {
            null
        }
        gPkg = pkg
        gFrames = n
        gT = now
        return r
    }
}
