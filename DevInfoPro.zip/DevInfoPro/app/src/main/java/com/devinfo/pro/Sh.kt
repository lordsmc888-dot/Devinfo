package com.devinfo.pro

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Runs shell commands: through Shizuku (shell uid) when granted, else as the plain app. */
object Sh {

    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun state(): String = try {
        when {
            !Shizuku.pingBinder() -> "Shizuku: OFF (limited info) - Shizuku app start karo"
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "Shizuku: ON (full info)"
            else -> "Shizuku: running, permission chahiye - button dabao"
        }
    } catch (e: Throwable) {
        "Shizuku: not available"
    }

    // Shizuku.newProcess is private since API 13, so call it by reflection.
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    fun run(cmd: String): String = try {
        val full = arrayOf("sh", "-c", "($cmd) 2>/dev/null")
        val p: Process = if (ready()) {
            newProcess.invoke(null, full, null, null) as Process
        } else {
            Runtime.getRuntime().exec(full)
        }
        val text = p.inputStream.bufferedReader().readText()
        p.waitFor()
        text
    } catch (e: Throwable) {
        ""
    }
}
