package com.devinfo.pro

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.view.WindowManager
import java.io.File
import java.util.Locale

object Info {

    class Core(val id: Int) {
        var cur = 0L // kHz
        var min = 0L
        var max = 0L
        var gov = ""
    }

    class Gpu {
        var freq = -1.0 // MHz
        var max = -1.0
        var load = ""
    }

    private const val CP = "/sys/devices/system/cpu/cpu[0-9]*/cpufreq/"
    private val coreRe = Regex("cpu(\\d+)/cpufreq/(\\w+):(.*)")
    private val gpuRe = Regex("(?i)kgsl|gpu|mali|g3d|pvr")
    private val ddrRe = Regex("(?i)ddr|dmc|bimc|mif|llcc")

    // ---------------------------------------------------------------- CPU

    fun cores(withLimits: Boolean = true): List<Core> {
        val files = if (withLimits) {
            "${CP}scaling_cur_freq ${CP}cpuinfo_min_freq ${CP}cpuinfo_max_freq ${CP}scaling_governor"
        } else {
            "${CP}scaling_cur_freq"
        }
        val raw = Sh.run("grep -H . $files")
        val map = sortedMapOf<Int, Core>()
        coreRe.findAll(raw).forEach { m ->
            val id = m.groupValues[1].toInt()
            val c = map.getOrPut(id) { Core(id) }
            val v = m.groupValues[3].trim()
            when (m.groupValues[2]) {
                "scaling_cur_freq" -> c.cur = v.toLongOrNull() ?: 0L
                "cpuinfo_min_freq" -> c.min = v.toLongOrNull() ?: 0L
                "cpuinfo_max_freq" -> c.max = v.toLongOrNull() ?: 0L
                "scaling_governor" -> c.gov = v
            }
        }
        return map.values.toList()
    }

    private fun cpuTotal(): Int {
        val s = try {
            File("/sys/devices/system/cpu/possible").readText().trim()
        } catch (e: Throwable) {
            ""
        }
        return s.substringAfter('-', "").toIntOrNull()?.plus(1) ?: Runtime.getRuntime().availableProcessors()
    }

    /** [mfr, model, platform, hardware, abi] */
    private fun soc(): List<String> {
        val l = Sh.run(
            "getprop ro.soc.manufacturer; getprop ro.soc.model; getprop ro.board.platform; " +
                "getprop ro.hardware; getprop ro.product.cpu.abi"
        ).split("\n")
        return List(5) { l.getOrElse(it) { "" }.trim() }
    }

    private var lastTot = 0L
    private var lastIdle = 0L
    private var loadPrimed = false

    /** Whole-CPU load in percent, -1 on the first call or if unreadable. */
    @Synchronized
    fun cpuLoad(): Int {
        val l = Sh.run("head -n 1 /proc/stat").trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (l.size < 5) return -1
        val idle = l[3] + l[4]
        val tot = l.sum()
        val dt = tot - lastTot
        val di = idle - lastIdle
        val primed = loadPrimed
        lastTot = tot
        lastIdle = idle
        loadPrimed = true
        return if (!primed || dt <= 0) -1 else (100 * (dt - di) / dt).toInt().coerceIn(0, 100)
    }

    private fun temps(): List<Pair<String, Double>> {
        val raw = Sh.run("grep -H . /sys/class/thermal/thermal_zone*/type /sys/class/thermal/thermal_zone*/temp")
        val types = HashMap<String, String>()
        val vals = HashMap<String, Double>()
        Regex("thermal_zone(\\d+)/(type|temp):(.*)").findAll(raw).forEach { m ->
            val z = m.groupValues[1]
            val v = m.groupValues[3].trim()
            if (m.groupValues[2] == "type") {
                types[z] = v
            } else {
                val d = v.toDoubleOrNull()
                if (d != null) vals[z] = if (Math.abs(d) >= 200) d / 1000.0 else d
            }
        }
        return vals.entries.sortedBy { it.key.toInt() }.mapNotNull { e ->
            val t = types[e.key]
            if (t != null && e.value in 1.0..130.0) Pair(t, e.value) else null
        }
    }

    // ---------------------------------------------------------------- GPU

    private fun toMhz(v: String): Double {
        val x = v.toDoubleOrNull() ?: return -1.0
        return when {
            x >= 1e7 -> x / 1e6 // Hz
            x >= 1e4 -> x / 1e3 // kHz
            else -> x
        }
    }

    fun gpuStats(): Gpu {
        val g = Gpu()
        val raw = Sh.run(
            "grep -H . /sys/class/kgsl/kgsl-3d0/gpuclk /sys/class/kgsl/kgsl-3d0/max_gpuclk " +
                "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage /sys/class/devfreq/*/cur_freq " +
                "/sys/class/devfreq/*/max_freq /sys/class/devfreq/*/load"
        )
        raw.lines().forEach { l ->
            val i = l.indexOf(':')
            if (i > 0) {
                val path = l.substring(0, i)
                val v = l.substring(i + 1).trim()
                if (gpuRe.containsMatchIn(path)) {
                    when (path.substringAfterLast('/')) {
                        "gpuclk", "cur_freq" -> if (g.freq < 0) g.freq = toMhz(v)
                        "max_gpuclk", "max_freq" -> if (g.max < 0) g.max = toMhz(v)
                        "gpu_busy_percentage", "load" -> if (g.load.isEmpty()) g.load = v
                    }
                }
            }
        }
        return g
    }

    private fun gpuLine(g: Gpu): String {
        if (g.freq < 0) return "GPU: freq not readable on this device"
        val sb = StringBuilder("GPU: ${g.freq.toInt()} MHz")
        if (g.max > 0) sb.append(" / max ${g.max.toInt()} MHz")
        if (g.load.isNotEmpty()) sb.append(" | load ${g.load}")
        return sb.toString()
    }

    // ---------------------------------------------------------------- RAM

    fun mem(): Map<String, Long> {
        val m = HashMap<String, Long>()
        try {
            File("/proc/meminfo").forEachLine { l ->
                val p = l.split(":")
                if (p.size == 2) m[p[0].trim()] = p[1].trim().split(" ")[0].toLongOrNull() ?: 0L
            }
        } catch (e: Throwable) {
        }
        return m
    }

    private fun gb(kb: Long) = String.format(Locale.US, "%.2f GB", kb / 1048576.0)

    private fun ramPct(m: Map<String, Long>): Int {
        val t = m["MemTotal"] ?: 0L
        val a = m["MemAvailable"] ?: 0L
        return if (t > 0) (100 * (t - a) / t).toInt() else -1
    }

    // ---------------------------------------------------------------- tabs

    fun render(tab: String, ctx: Context): String = when (tab) {
        "Live" -> live()
        "CPU" -> cpuTab()
        "GPU" -> gpuTab()
        "RAM" -> ramTab()
        "Battery" -> battery(ctx)
        "Device" -> device(ctx)
        "Display" -> display(ctx)
        "Sensors" -> sensors(ctx)
        else -> ""
    }

    private fun live(): String {
        val cs = cores(false)
        val load = cpuLoad()
        val g = gpuStats()
        val m = mem()
        val sb = StringBuilder()
        sb.append("CPU load: ").append(if (load >= 0) "$load %" else "...").append('\n')
        if (cs.isNotEmpty()) {
            val mx = cs.maxOf { it.cur } / 1000
            val avg = cs.map { it.cur }.average().toLong() / 1000
            sb.append("CPU freq: max $mx MHz | avg $avg MHz\n")
            sb.append(cs.joinToString("  ") { "c${it.id}:${it.cur / 1000}" }).append('\n')
        } else {
            sb.append("CPU freq: not readable\n")
        }
        sb.append(gpuLine(g)).append('\n')
        val pct = ramPct(m)
        if (pct >= 0) {
            val used = (m["MemTotal"] ?: 0L) - (m["MemAvailable"] ?: 0L)
            sb.append("RAM: $pct % (${gb(used)} / ${gb(m["MemTotal"] ?: 0L)})\n")
        }
        val t = temps().filter { Regex("(?i)cpu|gpu|soc|batt").containsMatchIn(it.first) }.take(4)
        if (t.isNotEmpty()) {
            sb.append("\nTemps:\n")
            t.forEach { sb.append(String.format(Locale.US, "  %-18s %.1f C\n", it.first, it.second)) }
        }
        sb.append("\nFPS: 'FPS overlay' button dabao, phir koi bhi game/app kholo.")
        return sb.toString()
    }

    private fun cpuTab(): String {
        val s = soc()
        val cs = cores()
        val name = listOf(s[0], s[1]).filter { it.isNotEmpty() }.joinToString(" ").ifEmpty { Build.HARDWARE }
        val load = cpuLoad()
        val loadTxt = if (load >= 0) "$load %" else "..."
        val sb = StringBuilder()
        sb.append("SoC: $name\n")
        sb.append("Platform: ${s[2].ifEmpty { Build.BOARD }}\n")
        sb.append("Hardware: ${s[3].ifEmpty { Build.HARDWARE }}\n")
        sb.append("ABI: ${Build.SUPPORTED_ABIS.joinToString()}\n")
        sb.append("Cores: ${cpuTotal()}\n")
        sb.append("Load: $loadTxt\n\n")
        val seen = HashSet<Int>()
        cs.forEach { c ->
            seen.add(c.id)
            sb.append(
                String.format(
                    Locale.US, "cpu%-2d %5d MHz  [%d-%d]  %s\n",
                    c.id, c.cur / 1000, c.min / 1000, c.max / 1000, c.gov
                )
            )
        }
        for (i in 0 until cpuTotal()) if (i !in seen) sb.append(String.format(Locale.US, "cpu%-2d offline\n", i))
        val t = temps().filter { Regex("(?i)cpu|soc|skin|batt").containsMatchIn(it.first) }.take(10)
        if (t.isNotEmpty()) {
            sb.append("\nTemps:\n")
            t.forEach { sb.append(String.format(Locale.US, "  %-18s %.1f C\n", it.first, it.second)) }
        }
        return sb.toString()
    }

    private fun gpuTab(): String {
        val gl = Sh.run("dumpsys SurfaceFlinger | grep -m1 GLES").trim()
        val sb = StringBuilder()
        sb.append("Renderer:\n")
            .append(if (gl.isNotEmpty()) gl.removePrefix("GLES:").trim() else "(Shizuku chahiye)")
            .append("\n\n")
        sb.append(gpuLine(gpuStats())).append('\n')
        val t = temps().filter { Regex("(?i)gpu").containsMatchIn(it.first) }.take(4)
        t.forEach { sb.append(String.format(Locale.US, "Temp %s: %.1f C\n", it.first, it.second)) }
        return sb.toString()
    }

    private fun ramTab(): String {
        val m = mem()
        val total = m["MemTotal"] ?: 0L
        val avail = m["MemAvailable"] ?: 0L
        val sb = StringBuilder()
        sb.append("Total: ${gb(total)}\n")
        sb.append("Available: ${gb(avail)}\n")
        sb.append("Used: ${gb(total - avail)} (${ramPct(m)} %)\n")
        sb.append("Free: ${gb(m["MemFree"] ?: 0L)}\n")
        sb.append("Cached: ${gb(m["Cached"] ?: 0L)}\n")
        sb.append("Swap: ${gb((m["SwapTotal"] ?: 0L) - (m["SwapFree"] ?: 0L))} / ${gb(m["SwapTotal"] ?: 0L)}\n")
        val raw = Sh.run("grep -H . /sys/class/devfreq/*/cur_freq /sys/class/devfreq/*/max_freq")
        val ddr = raw.lines().filter { l ->
            val i = l.indexOf(':')
            i > 0 && ddrRe.containsMatchIn(l.substring(0, i))
        }
        if (ddr.isNotEmpty()) {
            sb.append("\nMemory bus / DDR:\n")
            ddr.forEach { l ->
                val i = l.indexOf(':')
                val parts = l.substring(0, i).split('/')
                val label = parts.getOrElse(parts.size - 2) { "?" } + "/" + parts.last()
                sb.append("  $label: ${toMhz(l.substring(i + 1).trim()).toInt()} MHz\n")
            }
        } else {
            sb.append("\nRAM type/speed: kernel isne expose nahi ki.\n")
        }
        return sb.toString()
    }

    private fun battery(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return "No battery info"
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = when (i.getIntExtra(BatteryManager.EXTRA_STATUS, 0)) {
            2 -> "Charging"
            3 -> "Discharging"
            4 -> "Not charging"
            5 -> "Full"
            else -> "Unknown"
        }
        val health = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            2 -> "Good"
            3 -> "Overheat"
            4 -> "Dead"
            5 -> "Over voltage"
            7 -> "Cold"
            else -> "Unknown"
        }
        val plug = when (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            1 -> "AC"
            2 -> "USB"
            4 -> "Wireless"
            else -> "None"
        }
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) / 1000
        val sb = StringBuilder()
        sb.append("Level: ${if (scale > 0) lvl * 100 / scale else lvl} %\n")
        sb.append("Status: $status\nHealth: $health\nPlugged: $plug\n")
        sb.append("Temp: ${i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0} C\n")
        sb.append("Voltage: ${i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)} mV\n")
        sb.append("Current: $cur mA\n")
        sb.append("Technology: ${i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)}\n")
        return sb.toString()
    }

    private fun device(ctx: Context): String {
        val st = StatFs(Environment.getDataDirectory().path)
        val up = SystemClock.elapsedRealtime() / 1000
        val kernel = Sh.run("uname -r").trim().ifEmpty { System.getProperty("os.version") ?: "?" }
        val socModel = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else "?"
        val sb = StringBuilder()
        sb.append("Brand: ${Build.BRAND}\nManufacturer: ${Build.MANUFACTURER}\n")
        sb.append("Model: ${Build.MODEL}\nDevice: ${Build.DEVICE}\nBoard: ${Build.BOARD}\n")
        sb.append("SoC: $socModel\n")
        sb.append("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        sb.append("Security patch: ${Build.VERSION.SECURITY_PATCH}\n")
        sb.append("Build: ${Build.DISPLAY}\n")
        sb.append("Kernel: $kernel\n")
        sb.append("Bootloader: ${Build.BOOTLOADER}\n")
        sb.append("Storage (data): ${gb(st.availableBytes / 1024)} free / ${gb(st.totalBytes / 1024)}\n")
        sb.append("Uptime: ${up / 3600}h ${(up % 3600) / 60}m\n")
        sb.append("Fingerprint:\n${Build.FINGERPRINT}\n")
        return sb.toString()
    }

    @Suppress("DEPRECATION")
    private fun display(ctx: Context): String {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = wm.defaultDisplay
        val dm = ctx.resources.displayMetrics
        val sb = StringBuilder()
        sb.append("Resolution: ${dm.widthPixels} x ${dm.heightPixels}\n")
        sb.append("Density: ${dm.densityDpi} dpi (x${dm.density})\n")
        sb.append("Physical dpi: ${dm.xdpi.toInt()} x ${dm.ydpi.toInt()}\n")
        sb.append(String.format(Locale.US, "Current refresh: %.1f Hz\n", d.refreshRate))
        sb.append("\nSupported modes:\n")
        d.supportedModes.forEach {
            sb.append(String.format(Locale.US, "  %dx%d @ %.1f Hz\n", it.physicalWidth, it.physicalHeight, it.refreshRate))
        }
        return sb.toString()
    }

    private fun sensors(ctx: Context): String {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val l = sm.getSensorList(Sensor.TYPE_ALL)
        return "Sensors: ${l.size}\n\n" + l.joinToString("\n") { "- ${it.name} (${it.vendor})" }
    }

    // ---------------------------------------------------------------- overlay

    fun overlayLine(): String {
        val f = Fps.measure()
        val cs = cores(false)
        val load = cpuLoad()
        val g = gpuStats()
        val pct = ramPct(mem())
        val sb = StringBuilder()
        sb.append("FPS ").append(if (f != null) String.format(Locale.US, "%.0f", f.fps) else "--")
        if (f != null) sb.append("  ").append(f.pkg.takeLast(20))
        sb.append("\nCPU ").append(if (load >= 0) "$load%" else "--")
        if (cs.isNotEmpty()) sb.append("  ").append(cs.maxOf { it.cur } / 1000).append("MHz")
        sb.append("\nGPU ")
        sb.append(if (g.freq >= 0) "${g.freq.toInt()}MHz" else "--")
        if (g.load.isNotEmpty()) sb.append("  ").append(g.load)
        sb.append("\nRAM ").append(if (pct >= 0) "$pct%" else "--")
        return sb.toString()
    }
}
