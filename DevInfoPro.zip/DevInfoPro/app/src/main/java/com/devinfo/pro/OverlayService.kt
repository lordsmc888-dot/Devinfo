package com.devinfo.pro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/** Small floating box with FPS / CPU / GPU / RAM. Tap it to close. */
class OverlayService : Service() {

    private var wm: WindowManager? = null
    private var tv: TextView? = null
    @Volatile
    private var alive = false
    private val ui = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("DevInfo overlay chal raha hai")
            .setContentText("Overlay par tap karo = band")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (tv == null) {
            addOverlay()
            startLoop()
        }
        return START_NOT_STICKY
    }

    private fun addOverlay() {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        val t = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(0xAA000000.toInt())
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setPadding(14, 8, 14, 8)
            text = "starting..."
            setOnClickListener { stopSelf() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 8
            y = 90
        }
        w.addView(t, lp)
        wm = w
        tv = t
    }

    private fun startLoop() {
        alive = true
        Thread {
            while (alive) {
                val s = try {
                    Info.overlayLine()
                } catch (e: Throwable) {
                    "error: ${e.message}"
                }
                ui.post { tv?.text = s }
                try {
                    Thread.sleep(600)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
    }

    override fun onDestroy() {
        alive = false
        try {
            tv?.let { wm?.removeView(it) }
        } catch (e: Throwable) {
        }
        tv = null
        super.onDestroy()
    }
}
