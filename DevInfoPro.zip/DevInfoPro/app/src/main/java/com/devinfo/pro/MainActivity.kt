package com.devinfo.pro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    private lateinit var out: TextView
    private lateinit var status: TextView
    private val tabs = listOf("Live", "CPU", "GPU", "RAM", "Battery", "Device", "Display", "Sensors")

    @Volatile
    private var tab = "Live"
    @Volatile
    private var resumed = false
    private val busy = AtomicBoolean(false)
    private val ui = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()

    private val binderL = Shizuku.OnBinderReceivedListener { ui.post { refreshStatus() } }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, _ -> ui.post { refreshStatus() } }

    private val loop = object : Runnable {
        override fun run() {
            if (!resumed) return
            if (busy.compareAndSet(false, true)) {
                val t = tab
                bg.execute {
                    val text = try {
                        Info.render(t, this@MainActivity)
                    } catch (e: Throwable) {
                        "Error: ${e.message}"
                    }
                    ui.post { out.text = text }
                    busy.set(false)
                }
            }
            ui.postDelayed(this, 1500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#101418"))
            fitsSystemWindows = true
        }
        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(px(12), px(8), px(12), px(4))
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(btn("Shizuku permission") { askShizuku() })
            addView(btn("FPS overlay") { startOverlay() })
        }
        val tabRow = HorizontalScrollView(this).apply {
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            tabs.forEach { t ->
                row.addView(btn(t) {
                    tab = t
                    ui.removeCallbacks(loop)
                    ui.post(loop)
                })
            }
            addView(row)
        }
        out = TextView(this).apply {
            setTextColor(Color.parseColor("#CFE8FF"))
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setPadding(px(12), px(8), px(12), px(24))
            text = "loading..."
        }
        val scroll = ScrollView(this).apply { addView(out) }

        root.addView(status)
        root.addView(actions)
        root.addView(tabRow)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        Shizuku.addBinderReceivedListenerSticky(binderL)
        Shizuku.addRequestPermissionResultListener(permL)
    }

    private fun btn(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun refreshStatus() {
        status.text = Sh.state()
    }

    private fun askShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Shizuku chal nahi raha. Pehle Shizuku app start karo.")
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("Permission pehle se mili hui hai")
            } else {
                Shizuku.requestPermission(100)
            }
        } catch (e: Throwable) {
            toast("Shizuku error: ${e.message}")
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("'Display over other apps' allow karo, phir dobara button dabao")
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        toast("Overlay on. Ab koi game/app kholo. Overlay par tap = band")
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        refreshStatus()
        ui.post(loop)
    }

    override fun onPause() {
        resumed = false
        ui.removeCallbacks(loop)
        super.onPause()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderL)
        Shizuku.removeRequestPermissionResultListener(permL)
        bg.shutdown()
        super.onDestroy()
    }
}
